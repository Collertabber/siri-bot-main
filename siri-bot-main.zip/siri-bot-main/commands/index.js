import {Test} from "./debug.js"
import {Help} from "./help.js"

export const Commands = [
  Test,
  Help
];