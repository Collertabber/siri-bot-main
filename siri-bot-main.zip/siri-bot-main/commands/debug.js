const Test = {
  names: ["test"],
  func: ({chat})=>{
    chat.reply("Test completed")
  },
  description: "test"
};

export {Test}