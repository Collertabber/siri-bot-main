All this code is for making your bot use all the stuff that photop-client offers! 
-

IMPORTANT: Make sure you go into package.json file and add: "type": "module" | Also search for the file called ".replit" and delete everything in that file, then write "run: "node ."" Also, if you have the commands in different folders. Make sure you import the right files in <help.js> | Both of these actions will make the code work!

The current db should work on vscode and replit! You wont have to change it!

With this code in your bot, you will use photop-client to its highest limits! Also, you can add your bot into the EcoBot marketplace! (Ads, others buy items with their EcoBot money, and much more | To add your bot, dm: Abooby#5598 in discord)

Info:

- file: command_entry.js - This file make the commands that are sent inside the chat of a post (that is connected) work
- file: database.js - This file makes the data for a user that connects a post with the bot (add ranks if you want permissions to work)
- file: index.js - This file makes the bot work (make sure that you change the photop bot credentials)
- file: constants.js - This file stores your prefix(PREFIX), post connecting word (START), and other random little things
- folder: commands - This file holds all your commands!
- folder: commands | file: indes.js: This file is very important, it stores all the commands (when making a new command, make sure to add the variable of the command in there)
- folder: commands | file: debug.js - This file has the testing command (to test the bot | you can delete if you want)
- folder: commands | file: command.txt - This file has the command structure, itll help you with creating commands.